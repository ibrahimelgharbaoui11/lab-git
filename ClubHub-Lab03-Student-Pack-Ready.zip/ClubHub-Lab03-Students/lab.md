# Lab 03 — ClubHub | Student Lab

**DevOps Cell · Club Informatique & Télécom · 60 minutes · Beginners**

## The story

ClubHub is a small website for our student club. Someone accidentally removed the **CIT Hackathon** from its list of events. Your job is to use Git history to find out what happened, undo that mistake, and add your own event. Then you will collaborate with teammates using GitHub.

**Work alone on WSL for Part A. Work in teams of 3–4 in your browser for Part B.**

| Time | Activity |
|---|---|
| 00–10 min | A1: First commit (trainer-guided) |
| 10–20 min | A2: Investigate the missing event |
| 20–25 min | A3: Restore it with `git revert` (follow trainer) |
| 25–35 min | A4: Create a branch, add an event, and merge |
| 35–40 min | Move to your team's GitHub repository |
| 40–55 min | Edit, open PR, review, merge |
| 55–60 min | Recap and optional bonus |

## Before starting

You need WSL/Ubuntu with Git (`git --version`) and a GitHub account signed into your browser. Trainers must prepare and share a GitHub team repository ahead of Part B.

Open WSL **in the folder containing `setup.sh`**, then run:

```bash
bash setup.sh
```

This creates two separate Git repositories under `~/clubhub-beginner-lab/`:
- `practice/` is empty so you can make your first commit.
- `clubhub/` contains a five-commit project history to investigate.

> If the setup says the folder already exists, ask a trainer. Do not reset it without permission: reset erases your work.

### Useful commands

| Command | Purpose |
|---|---|
| `git status` | Show changed and staged files |
| `git add FILE` | Stage a file for the next commit |
| `git commit -m "MESSAGE"` | Save a commit |
| `git log --oneline` | View commit history |
| `git show HASH` | View a commit's changes |
| `git log -p -- FILE` | View changes to one file over time |
| `git revert HASH` | Undo a commit by making a new commit |
| `git switch -c NAME` | Create and enter a branch |
| `git switch main` | Return to the main branch |
| `git merge NAME` | Merge a branch into your current branch |

If history opens in a full-screen view, press `q` to exit.

---

## A1 — Your first commit (00–10 min)

```bash
cd ~/clubhub-beginner-lab/practice
```

Tell Git which author name and email to record (use your own details or a GitHub no-reply email):

```bash
git config user.name "Your Name"
git config user.email "you@example.com"
```

Make a file and commit it:

```bash
echo "Hello ClubHub!" > hello.txt
git status
git add hello.txt
git status
git commit -m "My first Git commit"
git log --oneline
```

**Question:** Why did you run `git add` before `git commit`?

## A2 — Who deleted the hackathon? (10–20 min)

Enter the second repository:

```bash
cd ~/clubhub-beginner-lab/clubhub
```

**Task 1 — Examine the history.**

```bash
git log --oneline
```

You should see five commits. Each line has a short **hash** and a commit **message**. Find one that looks related to editing events.

**Task 2 — Inspect the suspicious commit.**

```bash
git show HASH
```

Replace `HASH` with the short hash you saw next to the suspicious commit (do **not** type the literal word `HASH`). Lines starting with `-` were removed; lines starting with `+` were added.

**Task 3 — Check the event file's changes.**

```bash
git log -p -- events.html
```

**Answer these questions aloud to a trainer:**
1. What is the message of the commit that removed **CIT Hackathon**?
2. What file was changed?
3. Which lines in the diff show the deletion?

There are **no secret flags or codes** to find. The goal is to understand Git history.

## A3 — Restore the hackathon (20–25 min, trainer-guided)

A bad commit is already in the project's history. We will undo it without deleting history.

First, set your identity in the `clubhub/` repository too:

```bash
git config user.name "Your Name"
git config user.email "you@example.com"
```

Find the short hash next to **Small events cleanup**:

```bash
git log --oneline
```

Now **replace `HASH`** below with that commit's actual hash:

```bash
git revert --no-edit HASH
```

You should see a new commit that undoes the cleanup. Check the event returned:

```bash
grep 'CIT Hackathon' events.html
git log --oneline -2
```

**Question:** Did Git remove the old bad commit, or add a new commit to undo it?

## A4 — Add your own event on a branch (25–35 min)

```bash
git switch main
git switch -c feature/my-event
```

Edit the file:

```bash
nano events.html
```

Add **one new line inside the existing `<ul>`**, without deleting the current lines. Example:

```html
<li class="event">Python workshop</li>
```

Save in nano: **Ctrl+O**, Enter, then **Ctrl+X**.

```bash
git diff
git add events.html
git commit -m "Add Python workshop"
git switch main
git merge feature/my-event
git log --oneline --graph --all
```

Check your local work:

```bash
~/clubhub-beginner-lab/check.sh
```

There are **five checks** (first identity, first commit, restored hackathon, merged feature branch, new event). GitHub PRs are checked separately by trainers.

---

## Part B — GitHub teamwork (35–55 min)

**Teams of 3–4.** Your trainer gives your team a GitHub repository with `README.md`, `team.md`, and `events.md`. Use GitHub **in the browser** for this first workshop; no push/pull authentication is required.

1. Open the team repository and then `team.md`.
2. Click **Edit** (pencil). Edit **only your assigned member section**; use your first name or nickname, not a private email.
3. Choose **Create a new branch for this commit and start a pull request**, if available. Name the branch `member/your-name` (unique per person).
4. Create the pull request (PR) with a clear title, for example `Add Sara to team`.
5. Ask a teammate to review the **Files changed** and leave a review or comment.
6. Merge only after a teammate has reviewed. Confirm your name appears in `team.md` on `main`.

If two people edit the same place and a conflict occurs, ask a trainer. If GitHub permissions prevent approvals, leave a review comment and ask your trainer to verify it.

## Optional challenges (for fast students)

- Find who introduced `sponsors.md`: use `git log --oneline -- sponsors.md` then `git show HASH`.
- Create a second branch with a different event and merge it.
- Make a second PR to add a club event to `events.md` in your team repository.
- Ask the trainer to demonstrate a merge conflict.

### What you should be able to explain

- Git vs GitHub; working directory vs staging vs commit.
- How `git log` and `git show` help investigate mistakes.
- Why `git revert` makes a new commit.
- What a branch, merge, PR, and review are.
